=== Goodz ===

A Shop and Blog / Magazine Premium WordPress theme

Author: Themes Kingdom
Tags: responsive-layout, one-column, two-columns, three-columns, black, gray, green, white, dark, light, featured-images, custom-header, custom-background, custom-colors, custom-header, custom-menu, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready

Requires at least: 4.4.2
Tested up to: 4.4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.